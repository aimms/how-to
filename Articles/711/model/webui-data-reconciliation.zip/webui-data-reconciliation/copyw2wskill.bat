echo on
CD /D "%~dp0"
xcopy ..\..\..\sensai\*.* sensai /E /I /H /C
pause
