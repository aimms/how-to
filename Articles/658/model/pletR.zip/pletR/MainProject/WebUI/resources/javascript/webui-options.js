// Configure the highcharts widgets data overload threshold limit
// webui_highcharts_data_overload_threshold = 1000;