"""
Matrix transpose example

This script demonstrates how to define a Python function that can be registered and executed from AIMMS
using the AIMMS procedure `execute_python_statement`. This allows you to extend AIMMS projects with custom Python logic.

How it works:
-------------
1. Define Python functions in this script.
2. Register these functions by running the script in an AIMMS project.
3. Call the AIMMS procedure `execute_python_statement` with the function name to execute the Python code from AIMMS.

Example usage:
--------------
Suppose you have a function `transpose_matrix` defined below. 
You can register it and then call it from AIMMS:

    execute_python_statement("transpose_matrix()")

"""

from PythonScripts.singleton import my_aimms

def transpose_matrix():
    """
    Transposes matrix p to pt.
    """

    # Get the dataframe from AIMMS.
    p_df = my_aimms.p.data()

    # Define new order and column names
    pt_df = p_df.rename({'j': 'i', 'i': 'j', 'p': 'pt'})

    # Send data back to AIMMS.
    my_aimms.pt.assign(pt_df)
