Optimal Power Flow (OPF)
=============================

In this example, we will see how the problem of Optimal Power Flow (OPF) in a power system can be implemented and solved in AIMMS. In the following, we will first review the OPF problem, and then we will see its implementation in AIMMS.

.. note:: For more information about the OPF problem see {}.
.. note:: For the simpler Economic Dispatch problem see {}.

OPF problem
--------------------------
OPF is one of the most important problems to be solved in power systems. Essentially, the goal in OPF is to minimise an objective function (normally the total generation cost) while considering constraints of the power system. In the following, first the OPF formulation is explained, and then its implementation in AIMMS is described.

OPF Formulation
--------------------

OPF is an optimisation problem. The objective function, as mentioned above, is normally the total cost of generation, and can be defined as below:


.. math::
	f(x)= \displaystyle\sum_{i=1}^{ng} f^{\{ i\}}_P (P^{\{ i\}}_g) \label{objective} \tag{1} 

where :math:`x` is the vector of the optimisation variables, which are bus powers and voltages:

.. math::

	x={[P_g, Q_g, V_a, V_m]}^T \label{x} \tag{2} 
	
There are of course some constraints in this optimisation problem: active and reactive power balance equations for all buses, limits on transmission line, and also upper and lower limits for the vector of state variables x. These constraints are shown in equations below respectively:

.. math:: 

	S_{bus}(x)+S_d-S_g=0  \label{PowerBalance} \tag{3}
	
where

.. math:: 

	\begin{align}
		S_{bus}(X)=[V]{I_{bus}}^*=[V]{{Y}_{bus}}^*V^*  \label{con_s} \tag{4} \\
		({P_f}^{\{ i\}}(x))^2+{\left({Q_f}^{\lbrace i\rbrace}(x)\right)}^2 \leq {\left({S}^{\lbrace i\rbrace}_{{L}}\right)}^2 \label{con_Pf} \tag{5}	\\
		{\left({P_t}^{\lbrace i\rbrace}(x)\right)}^2+{\left({Q_t}^{\lbrace i\rbrace}(x)\right)}^2 \leq {\left({S}^{\lbrace i\rbrace}_{{L}}\right)}^2 \label{con_Pt} \tag{6} 		
	\end{align}
	

The optimisation problem can therefore be written as below:

.. math::
	\begin{align}
		\text{minimize } f(x)	\\
		\text{subject to } (\ref{con_s})-(\ref{con_Pt})
	\end{align}
	
	
OPF Implementation in AIMMS
-------------------------------	
