docker run --rm -it -v"/mnt/c/u/s/nirvana/0270 AIMMS-EO info/AIMMS-EO/BottledWaterArgs":/model \
-v"/mnt/c/u/s/Linux/License/keylessLicense":/data \
aimms:24.3.2.2 jobrunner --logconfig LoggerConfig.xml --procedure pr_test BottledWaterArgs.aimms \
let tp1 23.45 \
let sp1 "some interesting numbers here" \
let ar::pac1 12.34 \
let ar::spac1 "more specific information there" \
let nobody "one" \
run pr_testSap