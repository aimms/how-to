# Log of upgrading AIMMS application Data Reconciliation with a WebUI interface

This file logs the upgrade of AIMMS application Data Reconciliation with a WebUI interface by using its WinUI information.
It serves as a todo list for providing the finishing touch.

Mark items done with ✅, and mark items declined with ✘.

## 1 Page 'Data Reconciliation Application' with slug data_reconciliation_application

## 2 Page 'Data Reconciliation Application > Process Topology' with slug process_topology

## 3 Page 'Data Reconciliation Application > Process Topology > Units' with slug units

* [ ] The action GotoPage in action sequence is not yet converted to a corresponding action for WebUI
      see also https://documentation.aimms.com/user-guide/aimms-ide/Aimms/Page%20Manager/Page%20Objects/Button/Actions/index.html
      Location: on page 'Units' purpose button_action_sequence of 'MainProject'.

* [ ] unkown entry type Action in action sequence
      Location: on page 'Units' purpose button_action_sequence of 'MainProject'.

* [ ] The action GotoPage in action sequence is not yet converted to a corresponding action for WebUI
      see also https://documentation.aimms.com/user-guide/aimms-ide/Aimms/Page%20Manager/Page%20Objects/Button/Actions/index.html
      Location: on page 'Units' purpose button_action_sequence of 'MainProject'.

* [ ] unkown entry type Action in action sequence
      Location: on page 'Units' purpose button_action_sequence of 'MainProject'.

* [ ] The action GotoPage in action sequence is not yet converted to a corresponding action for WebUI
      see also https://documentation.aimms.com/user-guide/aimms-ide/Aimms/Page%20Manager/Page%20Objects/Button/Actions/index.html
      Location: on page 'Units' purpose button_action_sequence of 'MainProject'.

* [ ] unkown entry type Action in action sequence
      Location: on page 'Units' purpose button_action_sequence of 'MainProject'.

* [ ] The MenuCommand Command is not converted with text File-Exit as part of an action sequence.
      see also https://documentation.aimms.com/user-guide/aimms-ide/Aimms/Page%20Manager/Page%20Objects/Button/Actions/index.html
      Location: on page 'Units' purpose button_action_sequence of 'MainProject'.

* [ ] unkown entry type Action in action sequence
      Location: on page 'Units' purpose button_action_sequence of 'MainProject'.

* [ ] unkown entry type Action in action sequence
      Location: on page 'Units' purpose button_action_sequence of 'MainProject'.

* [ ] unkown entry type Action in action sequence
      Location: on page 'Units' purpose button_action_sequence of 'MainProject'.

* [ ] unkown entry type Action in action sequence
      Location: on page 'Units' purpose button_action_sequence of 'MainProject'.

* [ ] Picture object on Units uses MainProject\User Files\StartPage.jpg.  But this image does not exist, so no image widget is created
      Location: on page 'Units' purpose purpose: picture of 'MainProject'.

## 4 Page 'Data Reconciliation Application > Process Topology > Components' with slug components

* [ ] The action GotoPage in action sequence is not yet converted to a corresponding action for WebUI
      see also https://documentation.aimms.com/user-guide/aimms-ide/Aimms/Page%20Manager/Page%20Objects/Button/Actions/index.html
      Location: on page 'Components' purpose button_action_sequence of 'MainProject'.

* [ ] unkown entry type Action in action sequence
      Location: on page 'Components' purpose button_action_sequence of 'MainProject'.

* [ ] The action GotoPage in action sequence is not yet converted to a corresponding action for WebUI
      see also https://documentation.aimms.com/user-guide/aimms-ide/Aimms/Page%20Manager/Page%20Objects/Button/Actions/index.html
      Location: on page 'Components' purpose button_action_sequence of 'MainProject'.

* [ ] unkown entry type Action in action sequence
      Location: on page 'Components' purpose button_action_sequence of 'MainProject'.

* [ ] The action GotoPage in action sequence is not yet converted to a corresponding action for WebUI
      see also https://documentation.aimms.com/user-guide/aimms-ide/Aimms/Page%20Manager/Page%20Objects/Button/Actions/index.html
      Location: on page 'Components' purpose button_action_sequence of 'MainProject'.

* [ ] unkown entry type Action in action sequence
      Location: on page 'Components' purpose button_action_sequence of 'MainProject'.

* [ ] The MenuCommand Command is not converted with text File-Exit as part of an action sequence.
      see also https://documentation.aimms.com/user-guide/aimms-ide/Aimms/Page%20Manager/Page%20Objects/Button/Actions/index.html
      Location: on page 'Components' purpose button_action_sequence of 'MainProject'.

* [ ] unkown entry type Action in action sequence
      Location: on page 'Components' purpose button_action_sequence of 'MainProject'.

* [ ] unkown entry type Action in action sequence
      Location: on page 'Components' purpose button_action_sequence of 'MainProject'.

* [ ] unkown entry type Action in action sequence
      Location: on page 'Components' purpose button_action_sequence of 'MainProject'.

* [ ] unkown entry type Action in action sequence
      Location: on page 'Components' purpose button_action_sequence of 'MainProject'.

* [ ] Picture object on Components uses MainProject\User Files\StartPage.jpg.  But this image does not exist, so no image widget is created
      Location: on page 'Components' purpose purpose: picture of 'MainProject'.

## 5 Page 'Data Reconciliation Application > Process Topology > Process reactants' with slug process_reactants

* [ ] The action GotoPage in action sequence is not yet converted to a corresponding action for WebUI
      see also https://documentation.aimms.com/user-guide/aimms-ide/Aimms/Page%20Manager/Page%20Objects/Button/Actions/index.html
      Location: on page 'Process reactants' purpose button_action_sequence of 'MainProject'.

* [ ] unkown entry type Action in action sequence
      Location: on page 'Process reactants' purpose button_action_sequence of 'MainProject'.

* [ ] The action GotoPage in action sequence is not yet converted to a corresponding action for WebUI
      see also https://documentation.aimms.com/user-guide/aimms-ide/Aimms/Page%20Manager/Page%20Objects/Button/Actions/index.html
      Location: on page 'Process reactants' purpose button_action_sequence of 'MainProject'.

* [ ] unkown entry type Action in action sequence
      Location: on page 'Process reactants' purpose button_action_sequence of 'MainProject'.

* [ ] The action GotoPage in action sequence is not yet converted to a corresponding action for WebUI
      see also https://documentation.aimms.com/user-guide/aimms-ide/Aimms/Page%20Manager/Page%20Objects/Button/Actions/index.html
      Location: on page 'Process reactants' purpose button_action_sequence of 'MainProject'.

* [ ] unkown entry type Action in action sequence
      Location: on page 'Process reactants' purpose button_action_sequence of 'MainProject'.

* [ ] The MenuCommand Command is not converted with text File-Exit as part of an action sequence.
      see also https://documentation.aimms.com/user-guide/aimms-ide/Aimms/Page%20Manager/Page%20Objects/Button/Actions/index.html
      Location: on page 'Process reactants' purpose button_action_sequence of 'MainProject'.

* [ ] unkown entry type Action in action sequence
      Location: on page 'Process reactants' purpose button_action_sequence of 'MainProject'.

* [ ] unkown entry type Action in action sequence
      Location: on page 'Process reactants' purpose button_action_sequence of 'MainProject'.

* [ ] unkown entry type Action in action sequence
      Location: on page 'Process reactants' purpose button_action_sequence of 'MainProject'.

* [ ] unkown entry type Action in action sequence
      Location: on page 'Process reactants' purpose button_action_sequence of 'MainProject'.

* [ ] Picture object on Process reactants uses MainProject\User Files\StartPage.jpg.  But this image does not exist, so no image widget is created
      Location: on page 'Process reactants' purpose purpose: picture of 'MainProject'.

## 6 Page 'Data Reconciliation Application > Process Topology > Reactant composition' with slug reactant_composition

* [ ] The action GotoPage in action sequence is not yet converted to a corresponding action for WebUI
      see also https://documentation.aimms.com/user-guide/aimms-ide/Aimms/Page%20Manager/Page%20Objects/Button/Actions/index.html
      Location: on page 'Reactant composition' purpose button_action_sequence of 'MainProject'.

* [ ] unkown entry type Action in action sequence
      Location: on page 'Reactant composition' purpose button_action_sequence of 'MainProject'.

* [ ] The action GotoPage in action sequence is not yet converted to a corresponding action for WebUI
      see also https://documentation.aimms.com/user-guide/aimms-ide/Aimms/Page%20Manager/Page%20Objects/Button/Actions/index.html
      Location: on page 'Reactant composition' purpose button_action_sequence of 'MainProject'.

* [ ] unkown entry type Action in action sequence
      Location: on page 'Reactant composition' purpose button_action_sequence of 'MainProject'.

* [ ] The action GotoPage in action sequence is not yet converted to a corresponding action for WebUI
      see also https://documentation.aimms.com/user-guide/aimms-ide/Aimms/Page%20Manager/Page%20Objects/Button/Actions/index.html
      Location: on page 'Reactant composition' purpose button_action_sequence of 'MainProject'.

* [ ] unkown entry type Action in action sequence
      Location: on page 'Reactant composition' purpose button_action_sequence of 'MainProject'.

* [ ] The MenuCommand Command is not converted with text File-Exit as part of an action sequence.
      see also https://documentation.aimms.com/user-guide/aimms-ide/Aimms/Page%20Manager/Page%20Objects/Button/Actions/index.html
      Location: on page 'Reactant composition' purpose button_action_sequence of 'MainProject'.

* [ ] unkown entry type Action in action sequence
      Location: on page 'Reactant composition' purpose button_action_sequence of 'MainProject'.

* [ ] unkown entry type Action in action sequence
      Location: on page 'Reactant composition' purpose button_action_sequence of 'MainProject'.

* [ ] unkown entry type Action in action sequence
      Location: on page 'Reactant composition' purpose button_action_sequence of 'MainProject'.

* [ ] unkown entry type Action in action sequence
      Location: on page 'Reactant composition' purpose button_action_sequence of 'MainProject'.

* [ ] Picture object on Reactant composition uses MainProject\User Files\StartPage.jpg.  But this image does not exist, so no image widget is created
      Location: on page 'Reactant composition' purpose purpose: picture of 'MainProject'.

## 7 Page 'Data Reconciliation Application > Process Topology > Flows and components' with slug flows_and_components

* [ ] The action GotoPage in action sequence is not yet converted to a corresponding action for WebUI
      see also https://documentation.aimms.com/user-guide/aimms-ide/Aimms/Page%20Manager/Page%20Objects/Button/Actions/index.html
      Location: on page 'Flows and components' purpose button_action_sequence of 'MainProject'.

* [ ] unkown entry type Action in action sequence
      Location: on page 'Flows and components' purpose button_action_sequence of 'MainProject'.

* [ ] The action GotoPage in action sequence is not yet converted to a corresponding action for WebUI
      see also https://documentation.aimms.com/user-guide/aimms-ide/Aimms/Page%20Manager/Page%20Objects/Button/Actions/index.html
      Location: on page 'Flows and components' purpose button_action_sequence of 'MainProject'.

* [ ] unkown entry type Action in action sequence
      Location: on page 'Flows and components' purpose button_action_sequence of 'MainProject'.

* [ ] The action GotoPage in action sequence is not yet converted to a corresponding action for WebUI
      see also https://documentation.aimms.com/user-guide/aimms-ide/Aimms/Page%20Manager/Page%20Objects/Button/Actions/index.html
      Location: on page 'Flows and components' purpose button_action_sequence of 'MainProject'.

* [ ] unkown entry type Action in action sequence
      Location: on page 'Flows and components' purpose button_action_sequence of 'MainProject'.

* [ ] The MenuCommand Command is not converted with text File-Exit as part of an action sequence.
      see also https://documentation.aimms.com/user-guide/aimms-ide/Aimms/Page%20Manager/Page%20Objects/Button/Actions/index.html
      Location: on page 'Flows and components' purpose button_action_sequence of 'MainProject'.

* [ ] unkown entry type Action in action sequence
      Location: on page 'Flows and components' purpose button_action_sequence of 'MainProject'.

* [ ] unkown entry type Action in action sequence
      Location: on page 'Flows and components' purpose button_action_sequence of 'MainProject'.

* [ ] unkown entry type Action in action sequence
      Location: on page 'Flows and components' purpose button_action_sequence of 'MainProject'.

* [ ] unkown entry type Action in action sequence
      Location: on page 'Flows and components' purpose button_action_sequence of 'MainProject'.

* [ ] Picture object on Flows and components uses MainProject\User Files\StartPage.jpg.  But this image does not exist, so no image widget is created
      Location: on page 'Flows and components' purpose purpose: picture of 'MainProject'.

## 8 Page 'Data Reconciliation Application > Process Topology > Flow network' with slug flow_network

* [ ] Network object converted to a WebUI diagram widget (no GIS background and no longitude/latitude coordinate names).
      Location: on page 'Flow network' purpose network object of 'MainProject'.

* [ ] The action GotoPage in action sequence is not yet converted to a corresponding action for WebUI
      see also https://documentation.aimms.com/user-guide/aimms-ide/Aimms/Page%20Manager/Page%20Objects/Button/Actions/index.html
      Location: on page 'Flow network' purpose button_action_sequence of 'MainProject'.

* [ ] The action GotoPage in action sequence is not yet converted to a corresponding action for WebUI
      see also https://documentation.aimms.com/user-guide/aimms-ide/Aimms/Page%20Manager/Page%20Objects/Button/Actions/index.html
      Location: on page 'Flow network' purpose button_action_sequence of 'MainProject'.

* [ ] unkown entry type Action in action sequence
      Location: on page 'Flow network' purpose button_action_sequence of 'MainProject'.

* [ ] The action GotoPage in action sequence is not yet converted to a corresponding action for WebUI
      see also https://documentation.aimms.com/user-guide/aimms-ide/Aimms/Page%20Manager/Page%20Objects/Button/Actions/index.html
      Location: on page 'Flow network' purpose button_action_sequence of 'MainProject'.

* [ ] unkown entry type Action in action sequence
      Location: on page 'Flow network' purpose button_action_sequence of 'MainProject'.

* [ ] The action GotoPage in action sequence is not yet converted to a corresponding action for WebUI
      see also https://documentation.aimms.com/user-guide/aimms-ide/Aimms/Page%20Manager/Page%20Objects/Button/Actions/index.html
      Location: on page 'Flow network' purpose button_action_sequence of 'MainProject'.

* [ ] unkown entry type Action in action sequence
      Location: on page 'Flow network' purpose button_action_sequence of 'MainProject'.

* [ ] The MenuCommand Command is not converted with text File-Exit as part of an action sequence.
      see also https://documentation.aimms.com/user-guide/aimms-ide/Aimms/Page%20Manager/Page%20Objects/Button/Actions/index.html
      Location: on page 'Flow network' purpose button_action_sequence of 'MainProject'.

* [ ] unkown entry type Action in action sequence
      Location: on page 'Flow network' purpose button_action_sequence of 'MainProject'.

* [ ] unkown entry type Action in action sequence
      Location: on page 'Flow network' purpose button_action_sequence of 'MainProject'.

* [ ] unkown entry type Action in action sequence
      Location: on page 'Flow network' purpose button_action_sequence of 'MainProject'.

* [ ] unkown entry type Action in action sequence
      Location: on page 'Flow network' purpose button_action_sequence of 'MainProject'.

* [ ] Picture object on Flow network uses MainProject\User Files\StartPage.jpg.  But this image does not exist, so no image widget is created
      Location: on page 'Flow network' purpose purpose: picture of 'MainProject'.

* [ ] The action GotoPage in action sequence is not yet converted to a corresponding action for WebUI
      see also https://documentation.aimms.com/user-guide/aimms-ide/Aimms/Page%20Manager/Page%20Objects/Button/Actions/index.html
      Location: on page 'Process Topology' purpose button_action_sequence of 'MainProject'.

* [ ] unkown entry type Action in action sequence
      Location: on page 'Process Topology' purpose button_action_sequence of 'MainProject'.

* [ ] The action GotoPage in action sequence is not yet converted to a corresponding action for WebUI
      see also https://documentation.aimms.com/user-guide/aimms-ide/Aimms/Page%20Manager/Page%20Objects/Button/Actions/index.html
      Location: on page 'Process Topology' purpose button_action_sequence of 'MainProject'.

* [ ] unkown entry type Action in action sequence
      Location: on page 'Process Topology' purpose button_action_sequence of 'MainProject'.

* [ ] The action GotoPage in action sequence is not yet converted to a corresponding action for WebUI
      see also https://documentation.aimms.com/user-guide/aimms-ide/Aimms/Page%20Manager/Page%20Objects/Button/Actions/index.html
      Location: on page 'Process Topology' purpose button_action_sequence of 'MainProject'.

* [ ] unkown entry type Action in action sequence
      Location: on page 'Process Topology' purpose button_action_sequence of 'MainProject'.

* [ ] The MenuCommand Command is not converted with text File-Exit as part of an action sequence.
      see also https://documentation.aimms.com/user-guide/aimms-ide/Aimms/Page%20Manager/Page%20Objects/Button/Actions/index.html
      Location: on page 'Process Topology' purpose button_action_sequence of 'MainProject'.

* [ ] unkown entry type Action in action sequence
      Location: on page 'Process Topology' purpose button_action_sequence of 'MainProject'.

* [ ] unkown entry type Action in action sequence
      Location: on page 'Process Topology' purpose button_action_sequence of 'MainProject'.

* [ ] unkown entry type Action in action sequence
      Location: on page 'Process Topology' purpose button_action_sequence of 'MainProject'.

* [ ] unkown entry type Action in action sequence
      Location: on page 'Process Topology' purpose button_action_sequence of 'MainProject'.

* [ ] Picture object on Process Topology uses MainProject\User Files\StartPage.jpg.  But this image does not exist, so no image widget is created
      Location: on page 'Process Topology' purpose purpose: picture of 'MainProject'.

## 9 Page 'Data Reconciliation Application > Process Measurements' with slug process_measurements

## 10 Page 'Data Reconciliation Application > Process Measurements > Measured flows' with slug measured_flows

* [ ] The action GotoPage in action sequence is not yet converted to a corresponding action for WebUI
      see also https://documentation.aimms.com/user-guide/aimms-ide/Aimms/Page%20Manager/Page%20Objects/Button/Actions/index.html
      Location: on page 'Measured flows' purpose button_action_sequence of 'MainProject'.

* [ ] unkown entry type Action in action sequence
      Location: on page 'Measured flows' purpose button_action_sequence of 'MainProject'.

* [ ] The action GotoPage in action sequence is not yet converted to a corresponding action for WebUI
      see also https://documentation.aimms.com/user-guide/aimms-ide/Aimms/Page%20Manager/Page%20Objects/Button/Actions/index.html
      Location: on page 'Measured flows' purpose button_action_sequence of 'MainProject'.

* [ ] unkown entry type Action in action sequence
      Location: on page 'Measured flows' purpose button_action_sequence of 'MainProject'.

* [ ] The action GotoPage in action sequence is not yet converted to a corresponding action for WebUI
      see also https://documentation.aimms.com/user-guide/aimms-ide/Aimms/Page%20Manager/Page%20Objects/Button/Actions/index.html
      Location: on page 'Measured flows' purpose button_action_sequence of 'MainProject'.

* [ ] unkown entry type Action in action sequence
      Location: on page 'Measured flows' purpose button_action_sequence of 'MainProject'.

* [ ] The MenuCommand Command is not converted with text File-Exit as part of an action sequence.
      see also https://documentation.aimms.com/user-guide/aimms-ide/Aimms/Page%20Manager/Page%20Objects/Button/Actions/index.html
      Location: on page 'Measured flows' purpose button_action_sequence of 'MainProject'.

* [ ] unkown entry type Action in action sequence
      Location: on page 'Measured flows' purpose button_action_sequence of 'MainProject'.

* [ ] unkown entry type Action in action sequence
      Location: on page 'Measured flows' purpose button_action_sequence of 'MainProject'.

* [ ] unkown entry type Action in action sequence
      Location: on page 'Measured flows' purpose button_action_sequence of 'MainProject'.

* [ ] unkown entry type Action in action sequence
      Location: on page 'Measured flows' purpose button_action_sequence of 'MainProject'.

* [ ] Picture object on Measured flows uses MainProject\User Files\StartPage.jpg.  But this image does not exist, so no image widget is created
      Location: on page 'Measured flows' purpose purpose: picture of 'MainProject'.

## 11 Page 'Data Reconciliation Application > Process Measurements > Measured compositions' with slug measured_compositions

* [ ] The action GotoPage in action sequence is not yet converted to a corresponding action for WebUI
      see also https://documentation.aimms.com/user-guide/aimms-ide/Aimms/Page%20Manager/Page%20Objects/Button/Actions/index.html
      Location: on page 'Measured compositions' purpose button_action_sequence of 'MainProject'.

* [ ] unkown entry type Action in action sequence
      Location: on page 'Measured compositions' purpose button_action_sequence of 'MainProject'.

* [ ] The action GotoPage in action sequence is not yet converted to a corresponding action for WebUI
      see also https://documentation.aimms.com/user-guide/aimms-ide/Aimms/Page%20Manager/Page%20Objects/Button/Actions/index.html
      Location: on page 'Measured compositions' purpose button_action_sequence of 'MainProject'.

* [ ] unkown entry type Action in action sequence
      Location: on page 'Measured compositions' purpose button_action_sequence of 'MainProject'.

* [ ] The action GotoPage in action sequence is not yet converted to a corresponding action for WebUI
      see also https://documentation.aimms.com/user-guide/aimms-ide/Aimms/Page%20Manager/Page%20Objects/Button/Actions/index.html
      Location: on page 'Measured compositions' purpose button_action_sequence of 'MainProject'.

* [ ] unkown entry type Action in action sequence
      Location: on page 'Measured compositions' purpose button_action_sequence of 'MainProject'.

* [ ] The MenuCommand Command is not converted with text File-Exit as part of an action sequence.
      see also https://documentation.aimms.com/user-guide/aimms-ide/Aimms/Page%20Manager/Page%20Objects/Button/Actions/index.html
      Location: on page 'Measured compositions' purpose button_action_sequence of 'MainProject'.

* [ ] unkown entry type Action in action sequence
      Location: on page 'Measured compositions' purpose button_action_sequence of 'MainProject'.

* [ ] unkown entry type Action in action sequence
      Location: on page 'Measured compositions' purpose button_action_sequence of 'MainProject'.

* [ ] unkown entry type Action in action sequence
      Location: on page 'Measured compositions' purpose button_action_sequence of 'MainProject'.

* [ ] unkown entry type Action in action sequence
      Location: on page 'Measured compositions' purpose button_action_sequence of 'MainProject'.

* [ ] Picture object on Measured compositions uses MainProject\User Files\StartPage.jpg.  But this image does not exist, so no image widget is created
      Location: on page 'Measured compositions' purpose purpose: picture of 'MainProject'.

## 12 Page 'Data Reconciliation Application > Process Measurements > Measurement overview' with slug measurement_overview

* [ ] Network object converted to a WebUI diagram widget (no GIS background and no longitude/latitude coordinate names).
      Location: on page 'Measurement overview' purpose network object of 'MainProject'.

* [ ] The action GotoPage in action sequence is not yet converted to a corresponding action for WebUI
      see also https://documentation.aimms.com/user-guide/aimms-ide/Aimms/Page%20Manager/Page%20Objects/Button/Actions/index.html
      Location: on page 'Measurement overview' purpose button_action_sequence of 'MainProject'.

* [ ] unkown entry type Action in action sequence
      Location: on page 'Measurement overview' purpose button_action_sequence of 'MainProject'.

* [ ] The action GotoPage in action sequence is not yet converted to a corresponding action for WebUI
      see also https://documentation.aimms.com/user-guide/aimms-ide/Aimms/Page%20Manager/Page%20Objects/Button/Actions/index.html
      Location: on page 'Measurement overview' purpose button_action_sequence of 'MainProject'.

* [ ] unkown entry type Action in action sequence
      Location: on page 'Measurement overview' purpose button_action_sequence of 'MainProject'.

* [ ] The action GotoPage in action sequence is not yet converted to a corresponding action for WebUI
      see also https://documentation.aimms.com/user-guide/aimms-ide/Aimms/Page%20Manager/Page%20Objects/Button/Actions/index.html
      Location: on page 'Measurement overview' purpose button_action_sequence of 'MainProject'.

* [ ] unkown entry type Action in action sequence
      Location: on page 'Measurement overview' purpose button_action_sequence of 'MainProject'.

* [ ] The MenuCommand Command is not converted with text File-Exit as part of an action sequence.
      see also https://documentation.aimms.com/user-guide/aimms-ide/Aimms/Page%20Manager/Page%20Objects/Button/Actions/index.html
      Location: on page 'Measurement overview' purpose button_action_sequence of 'MainProject'.

* [ ] unkown entry type Action in action sequence
      Location: on page 'Measurement overview' purpose button_action_sequence of 'MainProject'.

* [ ] unkown entry type Action in action sequence
      Location: on page 'Measurement overview' purpose button_action_sequence of 'MainProject'.

* [ ] unkown entry type Action in action sequence
      Location: on page 'Measurement overview' purpose button_action_sequence of 'MainProject'.

* [ ] unkown entry type Action in action sequence
      Location: on page 'Measurement overview' purpose button_action_sequence of 'MainProject'.

* [ ] Picture object on Measurement overview uses MainProject\User Files\StartPage.jpg.  But this image does not exist, so no image widget is created
      Location: on page 'Measurement overview' purpose purpose: picture of 'MainProject'.

* [ ] The action GotoPage in action sequence is not yet converted to a corresponding action for WebUI
      see also https://documentation.aimms.com/user-guide/aimms-ide/Aimms/Page%20Manager/Page%20Objects/Button/Actions/index.html
      Location: on page 'Process Measurements' purpose button_action_sequence of 'MainProject'.

* [ ] unkown entry type Action in action sequence
      Location: on page 'Process Measurements' purpose button_action_sequence of 'MainProject'.

* [ ] The action GotoPage in action sequence is not yet converted to a corresponding action for WebUI
      see also https://documentation.aimms.com/user-guide/aimms-ide/Aimms/Page%20Manager/Page%20Objects/Button/Actions/index.html
      Location: on page 'Process Measurements' purpose button_action_sequence of 'MainProject'.

* [ ] unkown entry type Action in action sequence
      Location: on page 'Process Measurements' purpose button_action_sequence of 'MainProject'.

* [ ] The action GotoPage in action sequence is not yet converted to a corresponding action for WebUI
      see also https://documentation.aimms.com/user-guide/aimms-ide/Aimms/Page%20Manager/Page%20Objects/Button/Actions/index.html
      Location: on page 'Process Measurements' purpose button_action_sequence of 'MainProject'.

* [ ] unkown entry type Action in action sequence
      Location: on page 'Process Measurements' purpose button_action_sequence of 'MainProject'.

* [ ] The MenuCommand Command is not converted with text File-Exit as part of an action sequence.
      see also https://documentation.aimms.com/user-guide/aimms-ide/Aimms/Page%20Manager/Page%20Objects/Button/Actions/index.html
      Location: on page 'Process Measurements' purpose button_action_sequence of 'MainProject'.

* [ ] unkown entry type Action in action sequence
      Location: on page 'Process Measurements' purpose button_action_sequence of 'MainProject'.

* [ ] unkown entry type Action in action sequence
      Location: on page 'Process Measurements' purpose button_action_sequence of 'MainProject'.

* [ ] unkown entry type Action in action sequence
      Location: on page 'Process Measurements' purpose button_action_sequence of 'MainProject'.

* [ ] unkown entry type Action in action sequence
      Location: on page 'Process Measurements' purpose button_action_sequence of 'MainProject'.

* [ ] Picture object on Process Measurements uses MainProject\User Files\StartPage.jpg.  But this image does not exist, so no image widget is created
      Location: on page 'Process Measurements' purpose purpose: picture of 'MainProject'.

## 13 Page 'Data Reconciliation Application > Reconciliation' with slug reconciliation

## 14 Page 'Data Reconciliation Application > Reconciliation > Measured values' with slug measured_values

* [ ] The action GotoPage in action sequence is not yet converted to a corresponding action for WebUI
      see also https://documentation.aimms.com/user-guide/aimms-ide/Aimms/Page%20Manager/Page%20Objects/Button/Actions/index.html
      Location: on page 'Measured values' purpose button_action_sequence of 'MainProject'.

* [ ] unkown entry type Action in action sequence
      Location: on page 'Measured values' purpose button_action_sequence of 'MainProject'.

* [ ] The action GotoPage in action sequence is not yet converted to a corresponding action for WebUI
      see also https://documentation.aimms.com/user-guide/aimms-ide/Aimms/Page%20Manager/Page%20Objects/Button/Actions/index.html
      Location: on page 'Measured values' purpose button_action_sequence of 'MainProject'.

* [ ] unkown entry type Action in action sequence
      Location: on page 'Measured values' purpose button_action_sequence of 'MainProject'.

* [ ] The action GotoPage in action sequence is not yet converted to a corresponding action for WebUI
      see also https://documentation.aimms.com/user-guide/aimms-ide/Aimms/Page%20Manager/Page%20Objects/Button/Actions/index.html
      Location: on page 'Measured values' purpose button_action_sequence of 'MainProject'.

* [ ] unkown entry type Action in action sequence
      Location: on page 'Measured values' purpose button_action_sequence of 'MainProject'.

* [ ] The MenuCommand Command is not converted with text File-Exit as part of an action sequence.
      see also https://documentation.aimms.com/user-guide/aimms-ide/Aimms/Page%20Manager/Page%20Objects/Button/Actions/index.html
      Location: on page 'Measured values' purpose button_action_sequence of 'MainProject'.

* [ ] unkown entry type Action in action sequence
      Location: on page 'Measured values' purpose button_action_sequence of 'MainProject'.

* [ ] unkown entry type Action in action sequence
      Location: on page 'Measured values' purpose button_action_sequence of 'MainProject'.

* [ ] unkown entry type Action in action sequence
      Location: on page 'Measured values' purpose button_action_sequence of 'MainProject'.

* [ ] unkown entry type Action in action sequence
      Location: on page 'Measured values' purpose button_action_sequence of 'MainProject'.

* [ ] Picture object on Measured values uses MainProject\User Files\StartPage.jpg.  But this image does not exist, so no image widget is created
      Location: on page 'Measured values' purpose purpose: picture of 'MainProject'.

## 15 Page 'Data Reconciliation Application > Reconciliation > Run reconciliation model' with slug run_reconciliation_model

* [ ] The action GotoPage in action sequence is not yet converted to a corresponding action for WebUI
      see also https://documentation.aimms.com/user-guide/aimms-ide/Aimms/Page%20Manager/Page%20Objects/Button/Actions/index.html
      Location: on page 'Run reconciliation model' purpose button_action_sequence of 'MainProject'.

* [ ] unkown entry type Action in action sequence
      Location: on page 'Run reconciliation model' purpose button_action_sequence of 'MainProject'.

* [ ] The action GotoPage in action sequence is not yet converted to a corresponding action for WebUI
      see also https://documentation.aimms.com/user-guide/aimms-ide/Aimms/Page%20Manager/Page%20Objects/Button/Actions/index.html
      Location: on page 'Run reconciliation model' purpose button_action_sequence of 'MainProject'.

* [ ] unkown entry type Action in action sequence
      Location: on page 'Run reconciliation model' purpose button_action_sequence of 'MainProject'.

* [ ] The action GotoPage in action sequence is not yet converted to a corresponding action for WebUI
      see also https://documentation.aimms.com/user-guide/aimms-ide/Aimms/Page%20Manager/Page%20Objects/Button/Actions/index.html
      Location: on page 'Run reconciliation model' purpose button_action_sequence of 'MainProject'.

* [ ] unkown entry type Action in action sequence
      Location: on page 'Run reconciliation model' purpose button_action_sequence of 'MainProject'.

* [ ] The MenuCommand Command is not converted with text File-Exit as part of an action sequence.
      see also https://documentation.aimms.com/user-guide/aimms-ide/Aimms/Page%20Manager/Page%20Objects/Button/Actions/index.html
      Location: on page 'Run reconciliation model' purpose button_action_sequence of 'MainProject'.

* [ ] unkown entry type Action in action sequence
      Location: on page 'Run reconciliation model' purpose button_action_sequence of 'MainProject'.

* [ ] unkown entry type Action in action sequence
      Location: on page 'Run reconciliation model' purpose button_action_sequence of 'MainProject'.

* [ ] unkown entry type Action in action sequence
      Location: on page 'Run reconciliation model' purpose button_action_sequence of 'MainProject'.

* [ ] unkown entry type Action in action sequence
      Location: on page 'Run reconciliation model' purpose button_action_sequence of 'MainProject'.

* [ ] Picture object on Run reconciliation model uses MainProject\User Files\StartPage.jpg.  But this image does not exist, so no image widget is created
      Location: on page 'Run reconciliation model' purpose purpose: picture of 'MainProject'.

## 16 Page 'Data Reconciliation Application > Reconciliation > Measured vs. Reconciled' with slug measured_vs_reconciled

* [ ] The action GotoPage in action sequence is not yet converted to a corresponding action for WebUI
      see also https://documentation.aimms.com/user-guide/aimms-ide/Aimms/Page%20Manager/Page%20Objects/Button/Actions/index.html
      Location: on page 'Measured vs. Reconciled' purpose button_action_sequence of 'MainProject'.

* [ ] unkown entry type Action in action sequence
      Location: on page 'Measured vs. Reconciled' purpose button_action_sequence of 'MainProject'.

* [ ] The action GotoPage in action sequence is not yet converted to a corresponding action for WebUI
      see also https://documentation.aimms.com/user-guide/aimms-ide/Aimms/Page%20Manager/Page%20Objects/Button/Actions/index.html
      Location: on page 'Measured vs. Reconciled' purpose button_action_sequence of 'MainProject'.

* [ ] unkown entry type Action in action sequence
      Location: on page 'Measured vs. Reconciled' purpose button_action_sequence of 'MainProject'.

* [ ] The action GotoPage in action sequence is not yet converted to a corresponding action for WebUI
      see also https://documentation.aimms.com/user-guide/aimms-ide/Aimms/Page%20Manager/Page%20Objects/Button/Actions/index.html
      Location: on page 'Measured vs. Reconciled' purpose button_action_sequence of 'MainProject'.

* [ ] unkown entry type Action in action sequence
      Location: on page 'Measured vs. Reconciled' purpose button_action_sequence of 'MainProject'.

* [ ] The MenuCommand Command is not converted with text File-Exit as part of an action sequence.
      see also https://documentation.aimms.com/user-guide/aimms-ide/Aimms/Page%20Manager/Page%20Objects/Button/Actions/index.html
      Location: on page 'Measured vs. Reconciled' purpose button_action_sequence of 'MainProject'.

* [ ] unkown entry type Action in action sequence
      Location: on page 'Measured vs. Reconciled' purpose button_action_sequence of 'MainProject'.

* [ ] unkown entry type Action in action sequence
      Location: on page 'Measured vs. Reconciled' purpose button_action_sequence of 'MainProject'.

* [ ] unkown entry type Action in action sequence
      Location: on page 'Measured vs. Reconciled' purpose button_action_sequence of 'MainProject'.

* [ ] unkown entry type Action in action sequence
      Location: on page 'Measured vs. Reconciled' purpose button_action_sequence of 'MainProject'.

* [ ] Picture object on Measured vs. Reconciled uses MainProject\User Files\StartPage.jpg.  But this image does not exist, so no image widget is created
      Location: on page 'Measured vs. Reconciled' purpose purpose: picture of 'MainProject'.

## 17 Page 'Data Reconciliation Application > Reconciliation > Flow chart' with slug flow_chart

* [ ] Network object converted to a WebUI diagram widget (no GIS background and no longitude/latitude coordinate names).
      Location: on page 'Flow chart' purpose network object of 'MainProject'.

* [ ] The action GotoPage in action sequence is not yet converted to a corresponding action for WebUI
      see also https://documentation.aimms.com/user-guide/aimms-ide/Aimms/Page%20Manager/Page%20Objects/Button/Actions/index.html
      Location: on page 'Flow chart' purpose button_action_sequence of 'MainProject'.

* [ ] unkown entry type Action in action sequence
      Location: on page 'Flow chart' purpose button_action_sequence of 'MainProject'.

* [ ] The action GotoPage in action sequence is not yet converted to a corresponding action for WebUI
      see also https://documentation.aimms.com/user-guide/aimms-ide/Aimms/Page%20Manager/Page%20Objects/Button/Actions/index.html
      Location: on page 'Flow chart' purpose button_action_sequence of 'MainProject'.

* [ ] unkown entry type Action in action sequence
      Location: on page 'Flow chart' purpose button_action_sequence of 'MainProject'.

* [ ] The action GotoPage in action sequence is not yet converted to a corresponding action for WebUI
      see also https://documentation.aimms.com/user-guide/aimms-ide/Aimms/Page%20Manager/Page%20Objects/Button/Actions/index.html
      Location: on page 'Flow chart' purpose button_action_sequence of 'MainProject'.

* [ ] unkown entry type Action in action sequence
      Location: on page 'Flow chart' purpose button_action_sequence of 'MainProject'.

* [ ] The MenuCommand Command is not converted with text File-Exit as part of an action sequence.
      see also https://documentation.aimms.com/user-guide/aimms-ide/Aimms/Page%20Manager/Page%20Objects/Button/Actions/index.html
      Location: on page 'Flow chart' purpose button_action_sequence of 'MainProject'.

* [ ] unkown entry type Action in action sequence
      Location: on page 'Flow chart' purpose button_action_sequence of 'MainProject'.

* [ ] unkown entry type Action in action sequence
      Location: on page 'Flow chart' purpose button_action_sequence of 'MainProject'.

* [ ] unkown entry type Action in action sequence
      Location: on page 'Flow chart' purpose button_action_sequence of 'MainProject'.

* [ ] unkown entry type Action in action sequence
      Location: on page 'Flow chart' purpose button_action_sequence of 'MainProject'.

* [ ] Picture object on Flow chart uses MainProject\User Files\StartPage.jpg.  But this image does not exist, so no image widget is created
      Location: on page 'Flow chart' purpose purpose: picture of 'MainProject'.

## 18 Page 'Data Reconciliation Application > Reconciliation > Reconciled values' with slug reconciled_values

* [ ] The action GotoPage in action sequence is not yet converted to a corresponding action for WebUI
      see also https://documentation.aimms.com/user-guide/aimms-ide/Aimms/Page%20Manager/Page%20Objects/Button/Actions/index.html
      Location: on page 'Reconciled values' purpose button_action_sequence of 'MainProject'.

* [ ] unkown entry type Action in action sequence
      Location: on page 'Reconciled values' purpose button_action_sequence of 'MainProject'.

* [ ] The action GotoPage in action sequence is not yet converted to a corresponding action for WebUI
      see also https://documentation.aimms.com/user-guide/aimms-ide/Aimms/Page%20Manager/Page%20Objects/Button/Actions/index.html
      Location: on page 'Reconciled values' purpose button_action_sequence of 'MainProject'.

* [ ] unkown entry type Action in action sequence
      Location: on page 'Reconciled values' purpose button_action_sequence of 'MainProject'.

* [ ] The action GotoPage in action sequence is not yet converted to a corresponding action for WebUI
      see also https://documentation.aimms.com/user-guide/aimms-ide/Aimms/Page%20Manager/Page%20Objects/Button/Actions/index.html
      Location: on page 'Reconciled values' purpose button_action_sequence of 'MainProject'.

* [ ] unkown entry type Action in action sequence
      Location: on page 'Reconciled values' purpose button_action_sequence of 'MainProject'.

* [ ] The MenuCommand Command is not converted with text File-Exit as part of an action sequence.
      see also https://documentation.aimms.com/user-guide/aimms-ide/Aimms/Page%20Manager/Page%20Objects/Button/Actions/index.html
      Location: on page 'Reconciled values' purpose button_action_sequence of 'MainProject'.

* [ ] unkown entry type Action in action sequence
      Location: on page 'Reconciled values' purpose button_action_sequence of 'MainProject'.

* [ ] unkown entry type Action in action sequence
      Location: on page 'Reconciled values' purpose button_action_sequence of 'MainProject'.

* [ ] unkown entry type Action in action sequence
      Location: on page 'Reconciled values' purpose button_action_sequence of 'MainProject'.

* [ ] unkown entry type Action in action sequence
      Location: on page 'Reconciled values' purpose button_action_sequence of 'MainProject'.

* [ ] Picture object on Reconciled values uses MainProject\User Files\StartPage.jpg.  But this image does not exist, so no image widget is created
      Location: on page 'Reconciled values' purpose purpose: picture of 'MainProject'.

## 19 Page 'Data Reconciliation Application > Reconciliation > Compare multiple cases' with slug compare_multiple_cases

* [ ] The MenuCommand Command is not converted with text Data-Multiple Cases as part of an action sequence.
      see also https://documentation.aimms.com/user-guide/aimms-ide/Aimms/Page%20Manager/Page%20Objects/Button/Actions/index.html
      Location: on page 'Compare multiple cases' purpose button_action_sequence of 'MainProject'.

* [ ] The action GotoPage in action sequence is not yet converted to a corresponding action for WebUI
      see also https://documentation.aimms.com/user-guide/aimms-ide/Aimms/Page%20Manager/Page%20Objects/Button/Actions/index.html
      Location: on page 'Compare multiple cases' purpose button_action_sequence of 'MainProject'.

* [ ] unkown entry type Action in action sequence
      Location: on page 'Compare multiple cases' purpose button_action_sequence of 'MainProject'.

* [ ] The action GotoPage in action sequence is not yet converted to a corresponding action for WebUI
      see also https://documentation.aimms.com/user-guide/aimms-ide/Aimms/Page%20Manager/Page%20Objects/Button/Actions/index.html
      Location: on page 'Compare multiple cases' purpose button_action_sequence of 'MainProject'.

* [ ] unkown entry type Action in action sequence
      Location: on page 'Compare multiple cases' purpose button_action_sequence of 'MainProject'.

* [ ] The action GotoPage in action sequence is not yet converted to a corresponding action for WebUI
      see also https://documentation.aimms.com/user-guide/aimms-ide/Aimms/Page%20Manager/Page%20Objects/Button/Actions/index.html
      Location: on page 'Compare multiple cases' purpose button_action_sequence of 'MainProject'.

* [ ] unkown entry type Action in action sequence
      Location: on page 'Compare multiple cases' purpose button_action_sequence of 'MainProject'.

* [ ] The MenuCommand Command is not converted with text File-Exit as part of an action sequence.
      see also https://documentation.aimms.com/user-guide/aimms-ide/Aimms/Page%20Manager/Page%20Objects/Button/Actions/index.html
      Location: on page 'Compare multiple cases' purpose button_action_sequence of 'MainProject'.

* [ ] unkown entry type Action in action sequence
      Location: on page 'Compare multiple cases' purpose button_action_sequence of 'MainProject'.

* [ ] unkown entry type Action in action sequence
      Location: on page 'Compare multiple cases' purpose button_action_sequence of 'MainProject'.

* [ ] unkown entry type Action in action sequence
      Location: on page 'Compare multiple cases' purpose button_action_sequence of 'MainProject'.

* [ ] unkown entry type Action in action sequence
      Location: on page 'Compare multiple cases' purpose button_action_sequence of 'MainProject'.

* [ ] Picture object on Compare multiple cases uses MainProject\User Files\StartPage.jpg.  But this image does not exist, so no image widget is created
      Location: on page 'Compare multiple cases' purpose purpose: picture of 'MainProject'.

* [ ] The action GotoPage in action sequence is not yet converted to a corresponding action for WebUI
      see also https://documentation.aimms.com/user-guide/aimms-ide/Aimms/Page%20Manager/Page%20Objects/Button/Actions/index.html
      Location: on page 'Reconciliation' purpose button_action_sequence of 'MainProject'.

* [ ] unkown entry type Action in action sequence
      Location: on page 'Reconciliation' purpose button_action_sequence of 'MainProject'.

* [ ] The action GotoPage in action sequence is not yet converted to a corresponding action for WebUI
      see also https://documentation.aimms.com/user-guide/aimms-ide/Aimms/Page%20Manager/Page%20Objects/Button/Actions/index.html
      Location: on page 'Reconciliation' purpose button_action_sequence of 'MainProject'.

* [ ] unkown entry type Action in action sequence
      Location: on page 'Reconciliation' purpose button_action_sequence of 'MainProject'.

* [ ] The action GotoPage in action sequence is not yet converted to a corresponding action for WebUI
      see also https://documentation.aimms.com/user-guide/aimms-ide/Aimms/Page%20Manager/Page%20Objects/Button/Actions/index.html
      Location: on page 'Reconciliation' purpose button_action_sequence of 'MainProject'.

* [ ] unkown entry type Action in action sequence
      Location: on page 'Reconciliation' purpose button_action_sequence of 'MainProject'.

* [ ] The MenuCommand Command is not converted with text File-Exit as part of an action sequence.
      see also https://documentation.aimms.com/user-guide/aimms-ide/Aimms/Page%20Manager/Page%20Objects/Button/Actions/index.html
      Location: on page 'Reconciliation' purpose button_action_sequence of 'MainProject'.

* [ ] unkown entry type Action in action sequence
      Location: on page 'Reconciliation' purpose button_action_sequence of 'MainProject'.

* [ ] unkown entry type Action in action sequence
      Location: on page 'Reconciliation' purpose button_action_sequence of 'MainProject'.

* [ ] unkown entry type Action in action sequence
      Location: on page 'Reconciliation' purpose button_action_sequence of 'MainProject'.

* [ ] unkown entry type Action in action sequence
      Location: on page 'Reconciliation' purpose button_action_sequence of 'MainProject'.

* [ ] Picture object on Reconciliation uses MainProject\User Files\StartPage.jpg.  But this image does not exist, so no image widget is created
      Location: on page 'Reconciliation' purpose purpose: picture of 'MainProject'.

* [ ] unkown entry type Action in action sequence
      Location: on page 'Data Reconciliation Application' purpose button_action_sequence of 'MainProject'.

* [ ] unkown entry type Action in action sequence
      Location: on page 'Data Reconciliation Application' purpose button_action_sequence of 'MainProject'.

* [ ] Picture object on Data Reconciliation Application uses MainProject\User Files\StartPage.jpg.  But this image does not exist, so no image widget is created
      Location: on page 'Data Reconciliation Application' purpose purpose: picture of 'MainProject'.

## 20 Page 'Dev' with slug dev

## 21 Page 'Dev > Unit coordinates' with slug unit_coordinates

* [ ] unkown entry type Action in action sequence
      Location: on page 'Unit coordinates' purpose button_action_sequence of 'MainProject'.

* [ ] unkown entry type Action in action sequence
      Location: on page 'Unit coordinates' purpose button_action_sequence of 'MainProject'.

During the conversion 0 lines, 171 rectangles, 38 navigation objects, and 0 Data Page buttons were ignored.

