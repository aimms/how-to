// jquery.aimms.googlemap.js
jQuery.widget('ui.aimms_googlemap', AWF.Widget.create({
    _create: function() {
		var widget = this;
			    var xxx = '<div id="googleMap" style="width:100%;height:100%;"></div>';

				xxx = xxx + '<script>function myMap() {';
				xxx = xxx + 'var mapProp= {    center:new google.maps.LatLng(12.9716,77.5946),    zoom:11, };';
				xxx = xxx + 'var map=new google.maps.Map(document.getElementById("googleMap"),mapProp); ';
				xxx = xxx + '}</script>';


				xxx = xxx + '<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyATV45HjrFzUa4BbAy73DljOta7OgaajWA&callback=myMap"></script>';				
				
				// $.getJSON( 'https://maps.googleapis.com/maps/api/distancematrix/json?units=imperial&origins=Malleshwaram,Bangalore&destinations=Embassy+TechVillage,Bangalore&key=AIzaSyATV45HjrFzUa4BbAy73DljOta7OgaajWA', function( data )
				// {
					// console.log('Google API Data:');
					// console.log(data);					
				// } );

				widget.element.find('.awf-dock.center').empty();
				widget.element.find('.awf-dock.center').append($(xxx));

    },


	/**
	 * The most important message on the per-widget message bus is the 'resolvedOptionChanged' message.
	 * It has two arguments:
	 *
	 *	1) optionName		- The option name that was specified in the factory
	 *	2) value			- The value for the option. It can be 'null', which, if it is,
	 *						  means 'go back to the default value'. If it is non-null, the
	 *						  value is guaranteed to be of the type that the factory specified
	 *						  for the option.
	 */
	onResolvedOptionChanged: function(optionName, value) {
		var widget = this;

		if(optionName === "contents") {
			if(value) {
				// 'value' is the datasource (because in the factory we specified the 'contents' option to be a datasource)
				// 'rows' and 'cols' are the part names that we specified in the OptionTypeTable
				// 'table' because we want to access it as a table and not as a tree (value.list.tree); the extra '.table'
				// was a bad and obsolete idea, it is scheduled to be removed;
				this._fillGoogleMap(value);
			} else {
				javascript:alert("empty contents");
				this._create();
				//this.element.find('.awf-dock.center).empty();
			}
			}
	},
	
    _fillGoogleMap: function _fillGoogleMap(dataSource) {
    if (dataSource) {
		var widget = this;
        var numRowsInGrid = dataSource.values.getNumRows();
        var numColsInGrid = dataSource.values.getNumCols();
		var xxx = '';

        // Helper function to fill table cell with content
        function updateMap(text) {
			    var xxx = '<div id="googleMap" style="width:100%;height:100%;"></div>';
				xxx = xxx + text;
				xxx = xxx + '<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyATV45HjrFzUa4BbAy73DljOta7OgaajWA&callback=myMap"></script>';

				widget.element.find('.awf-dock.center').empty();
				widget.element.find('.awf-dock.center').append($(xxx));
        }
		
        // 2. Fill the string (uses asynchronous data retrieval)
        dataSource.requestDataBlocks(
            [
                {start: 0, end: numRowsInGrid},
                {start: 0, end: numColsInGrid},
            ],
            ["values"],
            function onReady(layeredDataBlocks) {
                ['values'].forEach(function(type) {
                    var partDataSource = dataSource[type];
                    partDataSource.getNumRows().times(function(row) {
                        partDataSource.getNumCols().times(function(col) {
							xxx = xxx.concat(layeredDataBlocks[type].getLayer("values").get(row, col));
                        });
                    });
                });
				updateMap(xxx);
            }
        );
    }
}	
}));