// factory.js
var OptionTypeTable = {
						type : "datasource",
					    parts : [ {name : "rowHeader"}, {name : "colHeader"} ],
						alternativeNameForValuesProperty: "grid",
					    preferredPartitionSizes : [	{parts: ["rowHeader","colHeader"]}, {parts: "aggregated"} ]
				      };


AWF.Bus.subscribe(
{
	
    onCollectTypes: function(collectedTypes, contextElQ) {
        if(!contextElQ || contextElQ.awf.tags("placeable-widget-container")) {
            collectedTypes.push("googlemap");
        }
    },

    onInitializeTags: function(elQ, type) {
        if (type === "googlemap") {
            elQ.awf.tags(["placeable", "fullscreenable"], 'add');
        }
    },

    onDecorateElement: function(elQ, type) {
        if(type === "googlemap") {
            elQ.aimms_googlemap();
        }
    },
	
	
	/**
	 * The initializeOptionTypes message allows this factory to declare which option this widget type has, and, what the option
	 * types for these options are.
	 */
	onInitializeOptionTypes: function(elQ, type) {
		if(type === "googlemap") {
			AWF.OptionTypeCollector.addOptionType(elQ, "contents", OptionTypeTable);
		}
	},

});
        