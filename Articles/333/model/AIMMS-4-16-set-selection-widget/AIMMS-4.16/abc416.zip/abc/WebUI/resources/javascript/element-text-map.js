ElementTextMap = {
     "sn" : "elaborateNames",
};

