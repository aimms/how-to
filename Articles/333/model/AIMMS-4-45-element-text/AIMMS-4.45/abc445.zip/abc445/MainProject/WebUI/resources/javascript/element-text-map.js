ElementTextMap = {
     "i_sn" : "sp_elaborateNames",
};

